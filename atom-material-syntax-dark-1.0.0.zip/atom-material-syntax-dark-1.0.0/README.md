![](http://i.imgur.com/f58FC9u.png)
---

A darker variant of [Atom Material Syntax](https://github.com/silvestreh/atom-material-ui) for [Atom Material UI](https://github.com/silvestreh/atom-material-ui). Inspired by Mattia Astorino's [SublimeText theme](https://github.com/equinusocio/material-theme).

![](http://i.imgur.com/2mxpDcl.png)
